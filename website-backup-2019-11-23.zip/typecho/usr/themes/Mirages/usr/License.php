<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * License.php
 * Author     : Hran
 * Date       : 2018/09/15
 * Version    :
 * Description:
 */
class License {
    static $name = "Mirages";
    static $pk = "SDlBT2NEOjE1MzY5OTk5MTg6ZDIwY2YxODFiNzc1YzA5NzVkMWM0YWVlYmY3ODYyNWQ1";
}
