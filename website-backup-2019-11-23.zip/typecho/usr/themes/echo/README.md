# Typecho 主题 Echo

一套基于layui框架的Typecho主题Echo,主题名取自博客域名（www.echo.so）

主题极简美观，并进行了响应式布局，使得博客在手机和平板电脑上也有更好的浏览阅读体验。

![](https://www.echo.so/typecho-echo.png)

演示地址：https://www.echo.so/

主题详情：https://www.echo.so/life/41.html

### 版本：1.2

#### 更新记录：

1.2.0 - 2019-7-25： 添加说说动态页，侧边栏增加博主动态和友情链接块。

1.2.1 - 2019-7-25： 修复侧边栏博主动态不显示动态列表问题。
